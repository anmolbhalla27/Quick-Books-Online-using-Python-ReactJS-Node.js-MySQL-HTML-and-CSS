import "./App.css";
import { useState, useEffect } from "react"

export default function App() {
  function ExportDB(){
    const url = "http://localhost:3000/api/db"; //HTTP PORT for database
  
      const fetchData = async () => {
        try {
          const response = await fetch(url);
          console.log(response.json);
          const json = await response.json();
  
          console.log(json);
          setData(json)
        } catch (error) {
          console.log("error", error);
        }
  
      };
      fetchData();
  }
  const [data, setData] = useState([]);
  useEffect(() => {
    const url = "http://localhost:3000/api/allData"; //HTTP PORT for all data

    const fetchData = async () => {
      try {
        const response = await fetch(url);
        console.log(response.json);
        const json = await response.json();

        console.log(json);
        setData(json)
      } catch (error) {
        console.log("error", error);
      }

    };
    fetchData();
  }, []);


  return (
    <>
        <div class="headerdiv">
          <div class="mainheader">Sandbox Company</div>
          <div class="header"><b>Statement of Cash Flow</b></div>
          <div class="headersummary">January - December 2022</div>
        </div>
        <div className="maindiv">
          <table className="months">
            <tr>
              <th></th>
            <th>Jan 2022</th>
            <th>Feb 2022</th>
            <th>March 2022</th>
            <th>Apr 2022</th>
            <th>May 2022</th>
              <th>Jun 2022</th>
              <th>Jul 2022</th>
              <th>Aug 2022</th>
              <th>Sep 2022</th>
              <th>Oct 2022</th>
              <th>Nov 2022</th>
              <th>Dec 2022</th>
              <th>TOTAL</th>
              </tr> 
            {data["alldata"] && data["alldata"].map((value) => {     
              //Using Map function to get all values from alldata
              return (
                <tr>
                  <td>
                  {/* Using ternary operator for identifying parent, child and subchild */}
                  {(value[0] === 1) ? <p className="space">{" "}</p> : (value[0] === 2) ? <p className="doublespace">{" "}</p> : <p className="triplespace">{" "}</p>} 
                  {value[1]}
                  </td>
                  <td>{value[2]}</td>
                  <td>{value[3]}</td>
                  <td>{value[4]}</td>
                  <td>{value[5]}</td>
                  <td>{value[6]}</td>
                  <td>{value[7]}</td>
                  <td>{value[8]}</td>
                  <td>{value[9]}</td>
                  <td>{value[10]}</td>
                  <td>{value[11]}</td>
                  <td>{value[12]}</td>
                  <td>{value[13]}</td>
                  <td>{value[14]}</td>
                </tr>
              );
            })}
          </table>
        </div>
        {/* onclick Event on Import button to store data to the database */}
        <div className="btn"><button onClick={ExportDB}>Import</button></div> 
    </>
  );
}