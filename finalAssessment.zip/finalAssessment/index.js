const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser'); 
const app = express();
const mysql = require('mysql')

//Creating Connection
const Con = mysql.createConnection({
    user: "root",
    host: "localhost",
    password: "Evergreen@123",
    database: "cashsheet",
});
  
Con.connect() 

app.use(bodyParser.json()); //Process data set in an HTTP request body
app.use(cors()) //prevent cross origin resource sharing on your server

let pythonFullData = {}

//HTTP POST allData request to the specified path
app.post('/api/allData',(req,res) => {
    const data = req.body;
    pythonFullData = data
})

//HTTP GET allData request from the specified path
app.get('/api/allData',(req,res) => {
    console.log(pythonFullData)
    res.json(pythonFullData)
})

let counter = 0

//HTTP GET db(database) request from the specified path
app.get('/api/db',(req,res) => {
    let headerList = pythonFullData["headerlist"] 
    let groupList = pythonFullData["grouplist"] 
    let summaryList = pythonFullData["summarylist"]
    if(counter==0){
        counter+=1
        Con.connect(function(err){
            //Iterating loop till length of the list
            for(var i=0;i<headerList.length;i++){
                //Inserting data into particular table
                Con.query(`INSERT INTO headerlist(id,valuee) VALUES(${headerList[i]['id']},"${headerList[i]['value']}");`,function(err,result){     //getting value from the particular location of the list
                    if(err) throw err;
                    console.log('valuesAdd')
                });
            }
            for(var i=0;i<groupList.length;i++){
                Con.query(`INSERT INTO grouplist(id,header_id,valuee) VALUES(${groupList[i]['id']},${groupList[i]['HeaderId']},"${groupList[i]['value']}");`,function(err,result){
                    if(err) throw err;
                    console.log('valuesAdd')
                });
            }
            for(var i=0;i<summaryList.length;i++){
                Con.query(`INSERT INTO summarylist(id,header_id,group_id,valuee) VALUES(${summaryList[i]['id']},${summaryList[i]['headerId']},${summaryList[i]['groupid']},"${summaryList[i]['value']}");`,function(err,result){
                    if(err) throw err;
                    console.log('valuesAdd')
                });
            }
        })
    }
})

app.listen(3000,() => {
    console.log('http://localhost:3000'); //HTTP main server PORT 
})