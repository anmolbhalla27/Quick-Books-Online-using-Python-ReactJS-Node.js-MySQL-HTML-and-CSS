import json
import requests

#OAuthTokens
oAuth_data = {
    "authentication": {
        "auth_code": "AB11675313456nifJeMnBnwerzobcvwtDuz3T8IqORAScxMlkP",
        "realm_id":4620816365273112100,
        "access_token": "eyJlbmMiOiJBMTI4Q0JDLUhTMjU2IiwiYWxnIjoiZGlyIn0..Oj6f-bODAUujwCAyXp6XfQ.5pZDFePQsH1169fYIJcoXPaHLHXIzm4_N5V7pU7-NnnC-3HOfaxJ4rgW0ClqPmrj6QmPMDCaBN4F69xu1cbIF1iHwz9NfYd_cm8OGaPiyPQDlee4anN8FfcKYOUs0VAyCBUfESVhw9Uz9GpVzSHNHtZr-wAOqicu1nZmaWx_DawpPx7U96lDbv1o38KS-sciXBlbyq3HCHazl5azTowedOBvM5rjnQsF9ToEcKavLuOUQQPJae-EnuJjz9_6Eggxvvol0kJkrfzAKGcyEl2Mklg0i-foM5qJLOIyNg9Ip1xdMCDI5C6asnrMVuYEh-BJ0J1fdrAAREIo4ByP6hev1BoS-xFIvt_64wNe935WijlU_heIEbRcwBlrPS4rbDjE-D5ga9tLTCu754OWHFKO-jZJ1dLCyVc2zct49eKyiFpMtgolJOOX3QA-_w4fPlkReoBNJu3QLa_uMtKZwqWJaMLhRtaxmCd3W3gbKp--xxHhNCOVVepYlfmwIAtNIVhf8c5Iwp0ZjUbokBWBPxXETJCv4zNokvkHUE_ExlMzhE4neFGy2hFw-sJK2N0LX_eOQdZBWPMr8DEfWrTQeGfRKOlPWoUj1fSPmGIbdtjsq465XoePW6bt6guhmSDRCmh57JrHNLk4wJPb9HKXbTQcHTPvj6xQDKwk8qcJYTiTUmW4KGkhyOkkptIx9aas5DzIRU0qUXNCJ8VdloEDw4zPWEFtv5VHpWaKZ67dHN7GBuLpH5nVrcL4ZakKXYRRsiyv._ADgwAOHvmTARDw78_PSeg"}
}

#This code is used to get json data from the API
def getCashFlowData(access_token):
    baseurl = 'https://sandbox-quickbooks.api.intuit.com'
    realm_id = oAuth_data['authentication']['realm_id']
    auth_header = 'Bearer {0}'.format(access_token)
    headers = {
        'Authorization': auth_header,
        'Accept': 'application/json'
    }

    cashFlowURL = f"{baseurl}/v3/company/{realm_id}/reports/CashFlow?summarize_column_by=Month&start_date=2022-01-01&end_date=2022-12-31&minorversion=65"
    response = requests.get(cashFlowURL, headers=headers)
    return json.loads(response.text)

#This code is used to destructure the nested JSON
out = {}
def flatten(x, name=""):
    if type(x) is dict:
        for a in x:
            flatten(x[a], name + a + "_")
    elif type(x) is list:
        i = 0
        for a in x:
            flatten(a, name + str(i) + "_")
            i += 1
    else:
        out[name[:-1]] = x

if __name__ == "__main__":
    res= getCashFlowData(access_token = oAuth_data['authentication']["access_token"])
    alldata = res
    flatten(res)
    json_object = json.dumps(out, indent = 4)
    #This code is used to store all the data of table rows
    j=0
    values=[]
    for i in out:
        if(i[len(i)-15:]=="ColData_0_value"):
            v1=[]
            v1.append(out[i])
            for j in range(1,14):
                strr = "" + i[:len(i)-7] + str(j) + i[len(i)-6:]
                v1.append(out[strr])
            if (i[len(i)-5:]=="group"):
                v1.append(out[i])
            values.append(v1)
    
    #This code contains the data that will storein the database
    newi = 0
    headerlist = [] #Contain headers only
    header_i = 0
    grouplist = [] #Contain groups only
    group_i = 0
    summarylist = [] #Contain summary only
    summary_i = 1
    headerid = 1
    groupid = 1
    isgroup = False
    for i in out:
        lis = i.split('_')
        ind = lis.count("Rows")
        if('Header_ColData_0_value' in i):
            if(ind == 1):
                values[newi].insert(0, 1)
            elif(ind == 2):
                values[newi].insert(0, 2)
            if(ind == 1):
                header_i = header_i + 1
                data ={"id": header_i, "value":out[i]}
                headerlist.append(data)
                if isgroup == True:
                    isgroup = False     
            else:
                group_i = group_i + 1
                data ={"id":group_i, "HeaderId":header_i, "value":out[i]}
                grouplist.append(data)
                groupid = group_i
                isgroup = True
            newi = newi+1
        elif('Summary_ColData_0_value' in i):
            if(ind == 2):
                values[newi].insert(0, 2)
            elif(ind == 1):
                values[newi].insert(0, 1)
            newi = newi+1
        elif("ColData_0_value" in i):
            if isgroup == True:
                data ={"id":summary_i, "headerId":header_i, "groupid": group_i, "value":out[i]}
                summarylist.append(data)
                summary_i = summary_i + 1 
            else:
                group_i = group_i + 1
                data ={"id":group_i, "HeaderId":header_i, "value":out[i]}
                grouplist.append(data)
            if(ind == 3):
                values[newi].insert(0, 3)
            elif(ind == 2):
                values[newi].insert(0, 2)
            elif(ind == 1):
                values[newi].insert(0, 1)
            newi = newi+1

    print('************************headerlist')
    print(headerlist)
    print('************************grouplist')
    print(grouplist)
    print('************************summarylist')
    print(summarylist)
    print('************************values')
    print(values)
    header = {"Content-Type": "application/json"}
    maindata = {} #Contain all of the data
    maindata.update({"alldata":values, "full":alldata, "headerlist":headerlist, "grouplist":grouplist, "summarylist":summarylist})
    res = requests.post("http://localhost:3000/api/allData",data=json.dumps(maindata),headers=header)
    print("Status Code: ", res.status_code)