CREATE SCHEMA cashsheet;
USE cashsheet;

create table headerlist(
id INT ,
valuee VARCHAR(255)
);

create table grouplist(
id INT,
header_id INT,
valuee VARCHAR(255)
);

create table summarylist(
id INT,
header_id INT,
group_id INT,
valuee VARCHAR(255)
);

select * from headerlist;
select * from grouplist;
select * from summarylist;